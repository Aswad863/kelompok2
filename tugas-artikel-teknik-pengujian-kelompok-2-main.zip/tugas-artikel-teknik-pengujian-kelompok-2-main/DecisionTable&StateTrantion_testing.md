# Teknik Pengujian Decision Table Testing dan State Transition Testing

## Konsep
### Gambar Ilustrasi
![Contoh Decision Table](./images/DecisionTable.png)
![Diagram State Transition](./images/StateTrantition.png)

### Penjelasan
#### Decision Table Testing
Decision Table Testing adalah teknik pengujian perangkat lunak yang digunakan untuk melihat bagaimana sistem merespons berbagai kemungkinan input dan output. Dalam teknik ini, semua aturan atau kondisi dibuat dalam bentuk tabel. Decision table adalah cara untuk memetakan hubungan antara input (masukan) dan aturan/kondisi dalam bentuk tabel yang mudah dibaca. Metode ini sangat berguna untuk perangkat lunak yang rumit karena membantu memastikan bahwa semua kombinasi kondisi telah diuji, sehingga tidak ada skenario yang terlewat. Kondisi dalam decision table biasanya ditunjukkan dengan nilai True atau False (Benar atau Salah).

#### State Transition Testing
State Transition Testing adalah jenis pengujian perangkat lunak yang digunakan untuk melihat bagaimana aplikasi berubah status ketika menerima input yang berbeda. Teknik ini mengamati bagaimana status aplikasi berubah saat diberikan berbagai kondisi input secara berurutan. Dalam State Transition Testing, penguji memberikan nilai input positif (input yang valid) dan negatif (input yang tidak valid) untuk melihat apakah aplikasi merespons dengan benar. Teknik ini termasuk dalam pengujian black box karena penguji tidak perlu mengetahui detail internal aplikasi, hanya perlu mengamati hasilnya saja. State Transition Testing sangat berguna ketika aplikasi memiliki banyak status berbeda yang perlu diuji, seperti pada sistem yang melibatkan login, pembayaran, atau alur kerja yang memiliki beberapa langkah.

## Langkah-langkah Pengujian
### Decision Table Testing
1. Identifikasi semua kondisi dan aksi.
2. Susun tabel keputusan dengan mencantumkan semua kombinasi kondisi.
3. Tetapkan aksi untuk setiap kombinasi kondisi.
4. Buat test case berdasarkan tabel keputusan.
5. Jalankan pengujian dan analisis hasilnya.

### State Transition Testing
1. Identifikasi semua status dan transisi yang mungkin.
2. Buat diagram atau tabel transisi status.
3. Tentukan input yang menyebabkan perpindahan status.
4. Buat test case untuk setiap transisi.
5. Jalankan pengujian dan verifikasi hasilnya.

## Contoh Kasus
### Decision Table Testing
#### Studi Kasus: Decision Table untuk Endpoint `/login`
![Study Case Decision Table](./case_study/StudyCase_DecisionTable.png)

Tabel keputusan di atas digunakan untuk menguji endpoint /login pada sebuah aplikasi. Tabel ini mencakup lima skenario utama:

- **Login Berhasil**: Ketika email dan password yang diberikan valid (admin), sistem memberikan status  HTTP 200 dengan pesan keberhasilan.
- **Email Tidak Diisi**: Jika email kosong (null), sistem memberikan status HTTP 400 dengan pesan bahwa email dan password harus diisi.
- **Password Tidak Diisi**: Jika password kosong (null), sistem juga memberikan status HTTP 400 dengan pesan serupa.
- **Email Tidak Valid**: Ketika email tidak dikenal (unknownUser), sistem memberikan status HTTP 401 dengan pesan bahwa email tidak valid.
- **Password Tidak Valid**: Jika password yang dimasukkan salah (wrongPassword), sistem memberikan status HTTP 401 dengan pesan bahwa password tidak valid.

Pengujian ini membantu memastikan bahwa semua kombinasi input yang mungkin telah diuji, sehingga sistem dapat menangani berbagai skenario dengan benar.

### State Trantition Testing
#### Studi Kasus: State Trantition untuk Endpoint `/login`
![Study Case Decision Table](./case_study/StudyCase_StateTrantition.png)

Tabel State Transition di atas digunakan untuk menggambarkan transisi status pada endpoint /login. Tabel ini mencakup beberapa skenario utama:

- **Transisi dari Idle ke Email Diisi**: Ketika pengguna mengisi email dengan input { email: 'admin' }, status berubah dari Idle menjadi Email Diisi. Tidak ada respons HTTP pada tahap ini.
- **Transisi dari Email Diisi ke Login Berhasil**: Jika password yang dimasukkan benar { password: 'admin' }, status berubah menjadi Login Berhasil. Sistem memberikan respons HTTP 200 dengan pesan:
{ "message": "Login berhasil" }.
- **Transisi dari Email Diisi ke Password Tidak Valid**: Jika password yang dimasukkan kosong { password: '' }, status berubah menjadi Password Tidak Valid. Sistem memberikan respons HTTP 401 dengan pesan:
{ "message": "Password tidak valid" }.
- **Transisi dari Idle ke Input Tidak Lengkap (Email Kosong)**: Jika email yang dimasukkan kosong { email: '' }, status berubah menjadi Input Tidak Lengkap. Sistem memberikan respons HTTP 400 dengan pesan:
{ "message": "Email dan password harus diisi" }.
- **Transisi dari Email Diisi ke Input Tidak Lengkap (Password Kosong)**: Jika password kosong { password: '' }, status berubah menjadi Input Tidak Lengkap. Sistem memberikan respons HTTP 400 dengan pesan:
{ "message": "Email dan password harus diisi" }.
- **Transisi dari Idle/Email Diisi ke Email Tidak Valid**: Jika email tidak dikenal { email: 'unknownUser' } meskipun password benar { password: 'admin' }, status berubah menjadi Email Tidak Valid. Sistem memberikan respons HTTP 401 dengan pesan:
{ "message": "Email tidak valid" }.
- **Transisi dari Email Diisi ke Password Tidak Valid (Password Salah)**: Jika password salah { password: 'wrongPassword' } meskipun email benar { email: 'admin' }, status berubah menjadi Password Tidak Valid. Sistem memberikan respons HTTP 401 dengan pesan:
{ "message": "Password tidak valid" }.

Pengujian ini memastikan bahwa setiap transisi status telah diuji, mencakup skenario input valid, tidak valid, atau kosong, sehingga sistem dapat menangani berbagai kondisi dengan benar.

## Kontributor
- [Saad Zaaghi (2200016096)](https://github.com/sazaghi)
- [Nama Kontributor 2](https://github.com/username2)
- [Nama Kontributor 3](https://github.com/username3)
