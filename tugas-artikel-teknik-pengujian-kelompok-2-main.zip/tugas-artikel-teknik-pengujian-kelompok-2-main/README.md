[![Review Assignment Due Date](https://classroom.github.com/assets/deadline-readme-button-22041afd0340ce965d47ae6ef1cefeee28c7c493a6346c4f15d667ab976d596c.svg)](https://classroom.github.com/a/55M5Bydz)
# Tugas  Membuat Artikel Teknik-teknik Pengujian

Instruksi:

- Buat artikel tentang teknik pengujian.
- Teknik yang ditulis adalah sesuai dengan topik kelompok presentasi.
- Buat file baru dengan format nama_teknik_pengujuan.md kemudian masukkan materi sesuai dengan outline yang ditentukan.
- Buat folder images untuk menyimpan gambar.
- Buat folder case_study untuk menyimpan project contoh kasus.

Outline Penulisan:
```
# [Judul Teknik Pengujuan]

## Konsep
### Gambar Ilustrasi

### Penjelasan

## Langkah-langkah Pengujian

## Contoh Kasus

## Kontributor

[Tulis daftar kontributor (anggota kelompok) beserta link github]

```
